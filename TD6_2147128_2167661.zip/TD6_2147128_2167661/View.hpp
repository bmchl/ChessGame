// TD6 INF 1015
// Michael Banna (2147128) & Nour Zahreddine (2167661)
// fichier View.hpp
// C'est le fichier g�n�r� par QtDesigner (de l'extension Qt VS Tools).
// Malgr� le fait qu'il compile, l'interface que nous avons con�u n'apparait pas.
// Notre second namespace "view" se situe ici.
/********************************************************************************
** Form generated from reading UI file 'ViewXhXAii.ui'
**
** Created by: Qt User Interface Compiler version 6.3.0
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef VIEWXHXAII_H
#define VIEWXHXAII_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QGridLayout>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE
namespace view
{
    class Ui_ChessWindow : public QMainWindow
    {
    public:
        QWidget* centralwidget;
        QWidget* gridLayoutWidget;
        QGridLayout* gridLayout;
        QPushButton* pushButton13;
        QPushButton* pushButton55;
        QPushButton* pushButton11;
        QPushButton* pushButton32;
        QPushButton* pushButton62;
        QPushButton* pushButton71;
        QPushButton* pushButton45;
        QPushButton* pushButton06;
        QPushButton* pushButton51;
        QPushButton* pushButton02;
        QPushButton* pushButton64;
        QPushButton* pushButton07;
        QPushButton* pushButton16;
        QPushButton* pushButton25;
        QPushButton* pushButton43;
        QPushButton* pushButton50;
        QPushButton* pushButton03;
        QPushButton* pushButton27;
        QPushButton* pushButton72;
        QPushButton* pushButton53;
        QPushButton* pushButton05;
        QPushButton* pushButton47;
        QPushButton* pushButton31;
        QPushButton* pushButton22;
        QPushButton* pushButton56;
        QPushButton* pushButton65;
        QPushButton* pushButton60;
        QPushButton* pushButton40;
        QPushButton* pushButton20;
        QPushButton* pushButton52;
        QPushButton* pushButton10;
        QPushButton* pushButton73;
        QPushButton* pushButton21;
        QPushButton* pushButton66;
        QPushButton* pushButton14;
        QPushButton* pushButton75;
        QPushButton* pushButton63;
        QPushButton* pushButton04;
        QPushButton* pushButton17;
        QPushButton* pushButton70;
        QPushButton* pushButton61;
        QPushButton* pushButton26;
        QPushButton* pushButton35;
        QPushButton* pushButton15;
        QPushButton* pushButton01;
        QPushButton* pushButton36;
        QPushButton* pushButton41;
        QPushButton* pushButton54;
        QPushButton* pushButton34;
        QPushButton* pushButton12;
        QPushButton* pushButton67;
        QPushButton* pushButton00;
        QPushButton* pushButton37;
        QPushButton* pushButton42;
        QPushButton* pushButton76;
        QPushButton* pushButton74;
        QPushButton* pushButton23;
        QPushButton* pushButton33;
        QPushButton* pushButton57;
        QPushButton* pushButton30;
        QPushButton* pushButton44;
        QPushButton* pushButton24;
        QPushButton* pushButton46;
        QPushButton* pushButton77;
        QWidget* horizontalLayoutWidget;
        QHBoxLayout* horizontalLayout_3;
        QVBoxLayout* verticalLayout_3;
        QPushButton* pieceChoice1;
        QPushButton* pieceChoice2;
        QPushButton* pieceChoice3;
        QVBoxLayout* verticalLayout;
        QPushButton* pieceChoice4;
        QPushButton* pieceChoice5;
        QPushButton* pieceChoice6;

        void setupUi(QMainWindow* ChessWindow)
        {
            if (ChessWindow->objectName().isEmpty())
                ChessWindow->setObjectName(QString::fromUtf8("ChessWindow"));
            ChessWindow->resize(990, 770);
            ChessWindow->setMinimumSize(QSize(990, 770));
            ChessWindow->setMaximumSize(QSize(990, 770));
            centralwidget = new QWidget(ChessWindow);
            centralwidget->setObjectName(QString::fromUtf8("centralwidget"));
            gridLayoutWidget = new QWidget(centralwidget);
            gridLayoutWidget->setObjectName(QString::fromUtf8("gridLayoutWidget"));
            gridLayoutWidget->setGeometry(QRect(230, 10, 770, 770));
            gridLayout = new QGridLayout(gridLayoutWidget);
            gridLayout->setObjectName(QString::fromUtf8("gridLayout"));
            gridLayout->setContentsMargins(0, 0, 0, 0);
            pushButton13 = new QPushButton(gridLayoutWidget);
            pushButton13->setObjectName(QString::fromUtf8("pushButton13"));
            pushButton13->setMinimumSize(QSize(80, 80));
            pushButton13->setMaximumSize(QSize(80, 80));
            pushButton13->setStyleSheet(QString::fromUtf8("background-color:rgb(241, 237, 233)"));
            pushButton13->setCheckable(false);

            gridLayout->addWidget(pushButton13, 1, 3, 1, 1);

            pushButton55 = new QPushButton(gridLayoutWidget);
            pushButton55->setObjectName(QString::fromUtf8("pushButton55"));
            pushButton55->setMinimumSize(QSize(80, 80));
            pushButton55->setMaximumSize(QSize(80, 80));
            pushButton55->setStyleSheet(QString::fromUtf8("background-color:rgb(241, 237, 233)"));
            pushButton55->setCheckable(false);

            gridLayout->addWidget(pushButton55, 5, 5, 1, 1);

            pushButton11 = new QPushButton(gridLayoutWidget);
            pushButton11->setObjectName(QString::fromUtf8("pushButton11"));
            pushButton11->setMinimumSize(QSize(80, 80));
            pushButton11->setMaximumSize(QSize(80, 80));
            pushButton11->setStyleSheet(QString::fromUtf8("background-color:rgb(241, 237, 233)"));
            pushButton11->setCheckable(false);

            gridLayout->addWidget(pushButton11, 1, 1, 1, 1);

            pushButton32 = new QPushButton(gridLayoutWidget);
            pushButton32->setObjectName(QString::fromUtf8("pushButton32"));
            pushButton32->setMinimumSize(QSize(80, 80));
            pushButton32->setMaximumSize(QSize(80, 80));
            pushButton32->setStyleSheet(QString::fromUtf8("background-color:rgb(75, 62, 75)"));
            pushButton32->setCheckable(false);

            gridLayout->addWidget(pushButton32, 3, 2, 1, 1);

            pushButton62 = new QPushButton(gridLayoutWidget);
            pushButton62->setObjectName(QString::fromUtf8("pushButton62"));
            pushButton62->setMinimumSize(QSize(80, 80));
            pushButton62->setMaximumSize(QSize(80, 80));
            pushButton62->setStyleSheet(QString::fromUtf8("background-color:rgb(241, 237, 233)"));
            pushButton62->setCheckable(false);

            gridLayout->addWidget(pushButton62, 6, 2, 1, 1);

            pushButton71 = new QPushButton(gridLayoutWidget);
            pushButton71->setObjectName(QString::fromUtf8("pushButton71"));
            pushButton71->setMinimumSize(QSize(80, 80));
            pushButton71->setMaximumSize(QSize(80, 80));
            pushButton71->setStyleSheet(QString::fromUtf8("background-color:rgb(241, 237, 233)"));
            pushButton71->setCheckable(false);

            gridLayout->addWidget(pushButton71, 7, 1, 1, 1);

            pushButton45 = new QPushButton(gridLayoutWidget);
            pushButton45->setObjectName(QString::fromUtf8("pushButton45"));
            pushButton45->setMinimumSize(QSize(80, 80));
            pushButton45->setMaximumSize(QSize(80, 80));
            pushButton45->setStyleSheet(QString::fromUtf8("background-color:rgb(75, 62, 75)"));
            pushButton45->setCheckable(false);

            gridLayout->addWidget(pushButton45, 4, 5, 1, 1);

            pushButton06 = new QPushButton(gridLayoutWidget);
            pushButton06->setObjectName(QString::fromUtf8("pushButton06"));
            pushButton06->setMinimumSize(QSize(80, 80));
            pushButton06->setMaximumSize(QSize(80, 80));
            pushButton06->setStyleSheet(QString::fromUtf8("background-color:rgb(241, 237, 233)"));
            pushButton06->setCheckable(false);

            gridLayout->addWidget(pushButton06, 0, 6, 1, 1);

            pushButton51 = new QPushButton(gridLayoutWidget);
            pushButton51->setObjectName(QString::fromUtf8("pushButton51"));
            pushButton51->setMinimumSize(QSize(80, 80));
            pushButton51->setMaximumSize(QSize(80, 80));
            pushButton51->setStyleSheet(QString::fromUtf8("background-color:rgb(241, 237, 233)"));
            pushButton51->setCheckable(false);

            gridLayout->addWidget(pushButton51, 5, 1, 1, 1);

            pushButton02 = new QPushButton(gridLayoutWidget);
            pushButton02->setObjectName(QString::fromUtf8("pushButton02"));
            pushButton02->setMinimumSize(QSize(80, 80));
            pushButton02->setMaximumSize(QSize(80, 80));
            pushButton02->setStyleSheet(QString::fromUtf8("background-color:rgb(241, 237, 233)"));
            pushButton02->setCheckable(false);

            gridLayout->addWidget(pushButton02, 0, 2, 1, 1);

            pushButton64 = new QPushButton(gridLayoutWidget);
            pushButton64->setObjectName(QString::fromUtf8("pushButton64"));
            pushButton64->setMinimumSize(QSize(80, 80));
            pushButton64->setMaximumSize(QSize(80, 80));
            pushButton64->setStyleSheet(QString::fromUtf8("background-color:rgb(241, 237, 233)"));
            pushButton64->setCheckable(false);

            gridLayout->addWidget(pushButton64, 6, 4, 1, 1);

            pushButton07 = new QPushButton(gridLayoutWidget);
            pushButton07->setObjectName(QString::fromUtf8("pushButton07"));
            pushButton07->setMinimumSize(QSize(80, 80));
            pushButton07->setMaximumSize(QSize(80, 80));
            pushButton07->setStyleSheet(QString::fromUtf8("background-color:rgb(75, 62, 75)"));
            pushButton07->setCheckable(false);

            gridLayout->addWidget(pushButton07, 0, 7, 1, 1);

            pushButton16 = new QPushButton(gridLayoutWidget);
            pushButton16->setObjectName(QString::fromUtf8("pushButton16"));
            pushButton16->setMinimumSize(QSize(80, 80));
            pushButton16->setMaximumSize(QSize(80, 80));
            pushButton16->setStyleSheet(QString::fromUtf8("background-color:rgb(75, 62, 75)"));
            pushButton16->setCheckable(false);

            gridLayout->addWidget(pushButton16, 1, 6, 1, 1);

            pushButton25 = new QPushButton(gridLayoutWidget);
            pushButton25->setObjectName(QString::fromUtf8("pushButton25"));
            pushButton25->setMinimumSize(QSize(80, 80));
            pushButton25->setMaximumSize(QSize(80, 80));
            pushButton25->setStyleSheet(QString::fromUtf8("background-color:rgb(75, 62, 75)"));
            pushButton25->setCheckable(false);

            gridLayout->addWidget(pushButton25, 2, 5, 1, 1);

            pushButton43 = new QPushButton(gridLayoutWidget);
            pushButton43->setObjectName(QString::fromUtf8("pushButton43"));
            pushButton43->setMinimumSize(QSize(80, 80));
            pushButton43->setMaximumSize(QSize(80, 80));
            pushButton43->setStyleSheet(QString::fromUtf8("background-color:rgb(75, 62, 75)"));
            pushButton43->setCheckable(false);

            gridLayout->addWidget(pushButton43, 4, 3, 1, 1);

            pushButton50 = new QPushButton(gridLayoutWidget);
            pushButton50->setObjectName(QString::fromUtf8("pushButton50"));
            pushButton50->setMinimumSize(QSize(80, 80));
            pushButton50->setMaximumSize(QSize(80, 80));
            pushButton50->setStyleSheet(QString::fromUtf8("background-color:rgb(75, 62, 75)"));
            pushButton50->setCheckable(false);

            gridLayout->addWidget(pushButton50, 5, 0, 1, 1);

            pushButton03 = new QPushButton(gridLayoutWidget);
            pushButton03->setObjectName(QString::fromUtf8("pushButton03"));
            pushButton03->setMinimumSize(QSize(80, 80));
            pushButton03->setMaximumSize(QSize(80, 80));
            pushButton03->setStyleSheet(QString::fromUtf8("background-color:rgb(75, 62, 75)"));
            pushButton03->setCheckable(false);

            gridLayout->addWidget(pushButton03, 0, 3, 1, 1);

            pushButton27 = new QPushButton(gridLayoutWidget);
            pushButton27->setObjectName(QString::fromUtf8("pushButton27"));
            pushButton27->setMinimumSize(QSize(80, 80));
            pushButton27->setMaximumSize(QSize(80, 80));
            pushButton27->setStyleSheet(QString::fromUtf8("background-color:rgb(75, 62, 75)"));
            pushButton27->setCheckable(false);

            gridLayout->addWidget(pushButton27, 2, 7, 1, 1);

            pushButton72 = new QPushButton(gridLayoutWidget);
            pushButton72->setObjectName(QString::fromUtf8("pushButton72"));
            pushButton72->setMinimumSize(QSize(80, 80));
            pushButton72->setMaximumSize(QSize(80, 80));
            pushButton72->setStyleSheet(QString::fromUtf8("background-color:rgb(75, 62, 75)"));
            pushButton72->setCheckable(false);

            gridLayout->addWidget(pushButton72, 7, 2, 1, 1);

            pushButton53 = new QPushButton(gridLayoutWidget);
            pushButton53->setObjectName(QString::fromUtf8("pushButton53"));
            pushButton53->setMinimumSize(QSize(80, 80));
            pushButton53->setMaximumSize(QSize(80, 80));
            pushButton53->setStyleSheet(QString::fromUtf8("background-color:rgb(241, 237, 233)"));
            pushButton53->setCheckable(false);

            gridLayout->addWidget(pushButton53, 5, 3, 1, 1);

            pushButton05 = new QPushButton(gridLayoutWidget);
            pushButton05->setObjectName(QString::fromUtf8("pushButton05"));
            pushButton05->setMinimumSize(QSize(80, 80));
            pushButton05->setMaximumSize(QSize(80, 80));
            pushButton05->setStyleSheet(QString::fromUtf8("background-color:rgb(75, 62, 75)"));
            pushButton05->setCheckable(false);

            gridLayout->addWidget(pushButton05, 0, 5, 1, 1);

            pushButton47 = new QPushButton(gridLayoutWidget);
            pushButton47->setObjectName(QString::fromUtf8("pushButton47"));
            pushButton47->setMinimumSize(QSize(80, 80));
            pushButton47->setMaximumSize(QSize(80, 80));
            pushButton47->setStyleSheet(QString::fromUtf8("background-color:rgb(75, 62, 75)"));
            pushButton47->setCheckable(false);

            gridLayout->addWidget(pushButton47, 4, 7, 1, 1);

            pushButton31 = new QPushButton(gridLayoutWidget);
            pushButton31->setObjectName(QString::fromUtf8("pushButton31"));
            pushButton31->setMinimumSize(QSize(80, 80));
            pushButton31->setMaximumSize(QSize(80, 80));
            pushButton31->setStyleSheet(QString::fromUtf8("background-color:rgb(241, 237, 233)"));
            pushButton31->setCheckable(false);

            gridLayout->addWidget(pushButton31, 3, 1, 1, 1);

            pushButton22 = new QPushButton(gridLayoutWidget);
            pushButton22->setObjectName(QString::fromUtf8("pushButton22"));
            pushButton22->setMinimumSize(QSize(80, 80));
            pushButton22->setMaximumSize(QSize(80, 80));
            pushButton22->setStyleSheet(QString::fromUtf8("background-color:rgb(241, 237, 233)"));
            pushButton22->setCheckable(false);

            gridLayout->addWidget(pushButton22, 2, 2, 1, 1);

            pushButton56 = new QPushButton(gridLayoutWidget);
            pushButton56->setObjectName(QString::fromUtf8("pushButton56"));
            pushButton56->setMinimumSize(QSize(80, 80));
            pushButton56->setMaximumSize(QSize(80, 80));
            pushButton56->setStyleSheet(QString::fromUtf8("background-color:rgb(75, 62, 75)"));
            pushButton56->setCheckable(false);

            gridLayout->addWidget(pushButton56, 5, 6, 1, 1);

            pushButton65 = new QPushButton(gridLayoutWidget);
            pushButton65->setObjectName(QString::fromUtf8("pushButton65"));
            pushButton65->setMinimumSize(QSize(80, 80));
            pushButton65->setMaximumSize(QSize(80, 80));
            pushButton65->setStyleSheet(QString::fromUtf8("background-color:rgb(75, 62, 75)"));
            pushButton65->setCheckable(false);

            gridLayout->addWidget(pushButton65, 6, 5, 1, 1);

            pushButton60 = new QPushButton(gridLayoutWidget);
            pushButton60->setObjectName(QString::fromUtf8("pushButton60"));
            pushButton60->setMinimumSize(QSize(80, 80));
            pushButton60->setMaximumSize(QSize(80, 80));
            pushButton60->setStyleSheet(QString::fromUtf8("background-color:rgb(241, 237, 233)"));
            pushButton60->setCheckable(false);

            gridLayout->addWidget(pushButton60, 6, 0, 1, 1);

            pushButton40 = new QPushButton(gridLayoutWidget);
            pushButton40->setObjectName(QString::fromUtf8("pushButton40"));
            pushButton40->setMinimumSize(QSize(80, 80));
            pushButton40->setMaximumSize(QSize(80, 80));
            pushButton40->setStyleSheet(QString::fromUtf8("background-color:rgb(241, 237, 233)"));
            pushButton40->setCheckable(false);

            gridLayout->addWidget(pushButton40, 4, 0, 1, 1);

            pushButton20 = new QPushButton(gridLayoutWidget);
            pushButton20->setObjectName(QString::fromUtf8("pushButton20"));
            pushButton20->setMinimumSize(QSize(80, 80));
            pushButton20->setMaximumSize(QSize(80, 80));
            pushButton20->setStyleSheet(QString::fromUtf8("background-color:rgb(241, 237, 233)"));
            pushButton20->setCheckable(false);

            gridLayout->addWidget(pushButton20, 2, 0, 1, 1);

            pushButton52 = new QPushButton(gridLayoutWidget);
            pushButton52->setObjectName(QString::fromUtf8("pushButton52"));
            pushButton52->setMinimumSize(QSize(80, 80));
            pushButton52->setMaximumSize(QSize(80, 80));
            pushButton52->setStyleSheet(QString::fromUtf8("background-color:rgb(75, 62, 75)"));
            pushButton52->setCheckable(false);

            gridLayout->addWidget(pushButton52, 5, 2, 1, 1);

            pushButton10 = new QPushButton(gridLayoutWidget);
            pushButton10->setObjectName(QString::fromUtf8("pushButton10"));
            pushButton10->setMinimumSize(QSize(80, 80));
            pushButton10->setMaximumSize(QSize(80, 80));
            pushButton10->setStyleSheet(QString::fromUtf8("background-color:rgb(75, 62, 75)"));
            pushButton10->setCheckable(false);

            gridLayout->addWidget(pushButton10, 1, 0, 1, 1);

            pushButton73 = new QPushButton(gridLayoutWidget);
            pushButton73->setObjectName(QString::fromUtf8("pushButton73"));
            pushButton73->setMinimumSize(QSize(80, 80));
            pushButton73->setMaximumSize(QSize(80, 80));
            pushButton73->setStyleSheet(QString::fromUtf8("background-color:rgb(241, 237, 233)"));
            pushButton73->setCheckable(false);

            gridLayout->addWidget(pushButton73, 7, 3, 1, 1);

            pushButton21 = new QPushButton(gridLayoutWidget);
            pushButton21->setObjectName(QString::fromUtf8("pushButton21"));
            pushButton21->setMinimumSize(QSize(80, 80));
            pushButton21->setMaximumSize(QSize(80, 80));
            pushButton21->setStyleSheet(QString::fromUtf8("background-color:rgb(75, 62, 75)"));
            pushButton21->setCheckable(false);

            gridLayout->addWidget(pushButton21, 2, 1, 1, 1);

            pushButton66 = new QPushButton(gridLayoutWidget);
            pushButton66->setObjectName(QString::fromUtf8("pushButton66"));
            pushButton66->setMinimumSize(QSize(80, 80));
            pushButton66->setMaximumSize(QSize(80, 80));
            pushButton66->setStyleSheet(QString::fromUtf8("background-color:rgb(241, 237, 233)"));
            pushButton66->setCheckable(false);

            gridLayout->addWidget(pushButton66, 6, 6, 1, 1);

            pushButton14 = new QPushButton(gridLayoutWidget);
            pushButton14->setObjectName(QString::fromUtf8("pushButton14"));
            pushButton14->setMinimumSize(QSize(80, 80));
            pushButton14->setMaximumSize(QSize(80, 80));
            pushButton14->setStyleSheet(QString::fromUtf8("background-color:rgb(75, 62, 75)"));
            pushButton14->setCheckable(false);

            gridLayout->addWidget(pushButton14, 1, 4, 1, 1);

            pushButton75 = new QPushButton(gridLayoutWidget);
            pushButton75->setObjectName(QString::fromUtf8("pushButton75"));
            pushButton75->setMinimumSize(QSize(80, 80));
            pushButton75->setMaximumSize(QSize(80, 80));
            pushButton75->setStyleSheet(QString::fromUtf8("background-color:rgb(241, 237, 233)"));
            pushButton75->setCheckable(false);

            gridLayout->addWidget(pushButton75, 7, 5, 1, 1);

            pushButton63 = new QPushButton(gridLayoutWidget);
            pushButton63->setObjectName(QString::fromUtf8("pushButton63"));
            pushButton63->setMinimumSize(QSize(80, 80));
            pushButton63->setMaximumSize(QSize(80, 80));
            pushButton63->setStyleSheet(QString::fromUtf8("background-color:rgb(75, 62, 75)"));
            pushButton63->setCheckable(false);

            gridLayout->addWidget(pushButton63, 6, 3, 1, 1);

            pushButton04 = new QPushButton(gridLayoutWidget);
            pushButton04->setObjectName(QString::fromUtf8("pushButton04"));
            pushButton04->setMinimumSize(QSize(80, 80));
            pushButton04->setMaximumSize(QSize(80, 80));
            pushButton04->setStyleSheet(QString::fromUtf8("background-color:rgb(241, 237, 233)"));
            pushButton04->setCheckable(false);

            gridLayout->addWidget(pushButton04, 0, 4, 1, 1);

            pushButton17 = new QPushButton(gridLayoutWidget);
            pushButton17->setObjectName(QString::fromUtf8("pushButton17"));
            pushButton17->setMinimumSize(QSize(80, 80));
            pushButton17->setMaximumSize(QSize(80, 80));
            pushButton17->setStyleSheet(QString::fromUtf8("background-color:rgb(241, 237, 233)"));
            pushButton17->setCheckable(false);

            gridLayout->addWidget(pushButton17, 1, 7, 1, 1);

            pushButton70 = new QPushButton(gridLayoutWidget);
            pushButton70->setObjectName(QString::fromUtf8("pushButton70"));
            pushButton70->setMinimumSize(QSize(80, 80));
            pushButton70->setMaximumSize(QSize(80, 80));
            pushButton70->setStyleSheet(QString::fromUtf8("background-color:rgb(75, 62, 75)"));
            pushButton70->setCheckable(false);

            gridLayout->addWidget(pushButton70, 7, 0, 1, 1);

            pushButton61 = new QPushButton(gridLayoutWidget);
            pushButton61->setObjectName(QString::fromUtf8("pushButton61"));
            pushButton61->setMinimumSize(QSize(80, 80));
            pushButton61->setMaximumSize(QSize(80, 80));
            pushButton61->setStyleSheet(QString::fromUtf8("background-color:rgb(75, 62, 75)"));
            pushButton61->setCheckable(false);

            gridLayout->addWidget(pushButton61, 6, 1, 1, 1);

            pushButton26 = new QPushButton(gridLayoutWidget);
            pushButton26->setObjectName(QString::fromUtf8("pushButton26"));
            pushButton26->setMinimumSize(QSize(80, 80));
            pushButton26->setMaximumSize(QSize(80, 80));
            pushButton26->setStyleSheet(QString::fromUtf8("background-color:rgb(241, 237, 233)"));
            pushButton26->setCheckable(false);

            gridLayout->addWidget(pushButton26, 2, 6, 1, 1);

            pushButton35 = new QPushButton(gridLayoutWidget);
            pushButton35->setObjectName(QString::fromUtf8("pushButton35"));
            pushButton35->setMinimumSize(QSize(80, 80));
            pushButton35->setMaximumSize(QSize(80, 80));
            pushButton35->setStyleSheet(QString::fromUtf8("background-color:rgb(241, 237, 233)"));
            pushButton35->setCheckable(false);

            gridLayout->addWidget(pushButton35, 3, 5, 1, 1);

            pushButton15 = new QPushButton(gridLayoutWidget);
            pushButton15->setObjectName(QString::fromUtf8("pushButton15"));
            pushButton15->setMinimumSize(QSize(80, 80));
            pushButton15->setMaximumSize(QSize(80, 80));
            pushButton15->setStyleSheet(QString::fromUtf8("background-color:rgb(241, 237, 233)"));
            pushButton15->setCheckable(false);

            gridLayout->addWidget(pushButton15, 1, 5, 1, 1);

            pushButton01 = new QPushButton(gridLayoutWidget);
            pushButton01->setObjectName(QString::fromUtf8("pushButton01"));
            pushButton01->setMinimumSize(QSize(80, 80));
            pushButton01->setMaximumSize(QSize(80, 80));
            pushButton01->setStyleSheet(QString::fromUtf8("background-color:rgb(75, 62, 75)"));
            pushButton01->setCheckable(false);

            gridLayout->addWidget(pushButton01, 0, 1, 1, 1);

            pushButton36 = new QPushButton(gridLayoutWidget);
            pushButton36->setObjectName(QString::fromUtf8("pushButton36"));
            pushButton36->setMinimumSize(QSize(80, 80));
            pushButton36->setMaximumSize(QSize(80, 80));
            pushButton36->setStyleSheet(QString::fromUtf8("background-color:rgb(75, 62, 75)"));
            pushButton36->setCheckable(false);

            gridLayout->addWidget(pushButton36, 3, 6, 1, 1);

            pushButton41 = new QPushButton(gridLayoutWidget);
            pushButton41->setObjectName(QString::fromUtf8("pushButton41"));
            pushButton41->setMinimumSize(QSize(80, 80));
            pushButton41->setMaximumSize(QSize(80, 80));
            pushButton41->setStyleSheet(QString::fromUtf8("background-color:rgb(75, 62, 75)"));
            pushButton41->setCheckable(false);

            gridLayout->addWidget(pushButton41, 4, 1, 1, 1);

            pushButton54 = new QPushButton(gridLayoutWidget);
            pushButton54->setObjectName(QString::fromUtf8("pushButton54"));
            pushButton54->setMinimumSize(QSize(80, 80));
            pushButton54->setMaximumSize(QSize(80, 80));
            pushButton54->setStyleSheet(QString::fromUtf8("background-color:rgb(75, 62, 75)"));
            pushButton54->setCheckable(false);

            gridLayout->addWidget(pushButton54, 5, 4, 1, 1);

            pushButton34 = new QPushButton(gridLayoutWidget);
            pushButton34->setObjectName(QString::fromUtf8("pushButton34"));
            pushButton34->setMinimumSize(QSize(80, 80));
            pushButton34->setMaximumSize(QSize(80, 80));
            pushButton34->setStyleSheet(QString::fromUtf8("background-color:rgb(75, 62, 75)"));
            pushButton34->setCheckable(false);

            gridLayout->addWidget(pushButton34, 3, 4, 1, 1);

            pushButton12 = new QPushButton(gridLayoutWidget);
            pushButton12->setObjectName(QString::fromUtf8("pushButton12"));
            pushButton12->setMinimumSize(QSize(80, 80));
            pushButton12->setMaximumSize(QSize(80, 80));
            pushButton12->setStyleSheet(QString::fromUtf8("background-color:rgb(75, 62, 75)"));
            pushButton12->setCheckable(false);

            gridLayout->addWidget(pushButton12, 1, 2, 1, 1);

            pushButton67 = new QPushButton(gridLayoutWidget);
            pushButton67->setObjectName(QString::fromUtf8("pushButton67"));
            pushButton67->setMinimumSize(QSize(80, 80));
            pushButton67->setMaximumSize(QSize(80, 80));
            pushButton67->setStyleSheet(QString::fromUtf8("background-color:rgb(75, 62, 75)"));
            pushButton67->setCheckable(false);

            gridLayout->addWidget(pushButton67, 6, 7, 1, 1);

            pushButton00 = new QPushButton(gridLayoutWidget);
            pushButton00->setObjectName(QString::fromUtf8("pushButton00"));
            pushButton00->setMinimumSize(QSize(80, 80));
            pushButton00->setMaximumSize(QSize(80, 80));
            pushButton00->setStyleSheet(QString::fromUtf8("background-color:rgb(241, 237, 233)"));
            pushButton00->setCheckable(false);

            gridLayout->addWidget(pushButton00, 0, 0, 1, 1);

            pushButton37 = new QPushButton(gridLayoutWidget);
            pushButton37->setObjectName(QString::fromUtf8("pushButton37"));
            pushButton37->setMinimumSize(QSize(80, 80));
            pushButton37->setMaximumSize(QSize(80, 80));
            pushButton37->setStyleSheet(QString::fromUtf8("background-color:rgb(241, 237, 233)"));
            pushButton37->setCheckable(false);

            gridLayout->addWidget(pushButton37, 3, 7, 1, 1);

            pushButton42 = new QPushButton(gridLayoutWidget);
            pushButton42->setObjectName(QString::fromUtf8("pushButton42"));
            pushButton42->setMinimumSize(QSize(80, 80));
            pushButton42->setMaximumSize(QSize(80, 80));
            pushButton42->setStyleSheet(QString::fromUtf8("background-color:rgb(241, 237, 233)"));
            pushButton42->setCheckable(false);

            gridLayout->addWidget(pushButton42, 4, 2, 1, 1);

            pushButton76 = new QPushButton(gridLayoutWidget);
            pushButton76->setObjectName(QString::fromUtf8("pushButton76"));
            pushButton76->setMinimumSize(QSize(80, 80));
            pushButton76->setMaximumSize(QSize(80, 80));
            pushButton76->setStyleSheet(QString::fromUtf8("background-color:rgb(75, 62, 75)"));
            pushButton76->setCheckable(false);

            gridLayout->addWidget(pushButton76, 7, 6, 1, 1);

            pushButton74 = new QPushButton(gridLayoutWidget);
            pushButton74->setObjectName(QString::fromUtf8("pushButton74"));
            pushButton74->setMinimumSize(QSize(80, 80));
            pushButton74->setMaximumSize(QSize(80, 80));
            pushButton74->setStyleSheet(QString::fromUtf8("background-color:rgb(75, 62, 75)"));
            pushButton74->setCheckable(false);

            gridLayout->addWidget(pushButton74, 7, 4, 1, 1);

            pushButton23 = new QPushButton(gridLayoutWidget);
            pushButton23->setObjectName(QString::fromUtf8("pushButton23"));
            pushButton23->setMinimumSize(QSize(80, 80));
            pushButton23->setMaximumSize(QSize(80, 80));
            pushButton23->setStyleSheet(QString::fromUtf8("background-color:rgb(75, 62, 75)"));
            pushButton23->setCheckable(false);

            gridLayout->addWidget(pushButton23, 2, 3, 1, 1);

            pushButton33 = new QPushButton(gridLayoutWidget);
            pushButton33->setObjectName(QString::fromUtf8("pushButton33"));
            pushButton33->setMinimumSize(QSize(80, 80));
            pushButton33->setMaximumSize(QSize(80, 80));
            pushButton33->setStyleSheet(QString::fromUtf8("background-color:rgb(241, 237, 233)"));
            pushButton33->setCheckable(false);

            gridLayout->addWidget(pushButton33, 3, 3, 1, 1);

            pushButton57 = new QPushButton(gridLayoutWidget);
            pushButton57->setObjectName(QString::fromUtf8("pushButton57"));
            pushButton57->setMinimumSize(QSize(80, 80));
            pushButton57->setMaximumSize(QSize(80, 80));
            pushButton57->setStyleSheet(QString::fromUtf8("background-color:rgb(241, 237, 233)"));
            pushButton57->setCheckable(false);

            gridLayout->addWidget(pushButton57, 5, 7, 1, 1);

            pushButton30 = new QPushButton(gridLayoutWidget);
            pushButton30->setObjectName(QString::fromUtf8("pushButton30"));
            pushButton30->setMinimumSize(QSize(80, 80));
            pushButton30->setMaximumSize(QSize(80, 80));
            pushButton30->setStyleSheet(QString::fromUtf8("background-color:rgb(75, 62, 75)"));
            pushButton30->setCheckable(false);

            gridLayout->addWidget(pushButton30, 3, 0, 1, 1);

            pushButton44 = new QPushButton(gridLayoutWidget);
            pushButton44->setObjectName(QString::fromUtf8("pushButton44"));
            pushButton44->setMinimumSize(QSize(80, 80));
            pushButton44->setMaximumSize(QSize(80, 80));
            pushButton44->setStyleSheet(QString::fromUtf8("background-color:rgb(241, 237, 233)"));
            pushButton44->setCheckable(false);

            gridLayout->addWidget(pushButton44, 4, 4, 1, 1);

            pushButton24 = new QPushButton(gridLayoutWidget);
            pushButton24->setObjectName(QString::fromUtf8("pushButton24"));
            pushButton24->setMinimumSize(QSize(80, 80));
            pushButton24->setMaximumSize(QSize(80, 80));
            pushButton24->setStyleSheet(QString::fromUtf8("background-color:rgb(241, 237, 233)"));
            pushButton24->setCheckable(false);

            gridLayout->addWidget(pushButton24, 2, 4, 1, 1);

            pushButton46 = new QPushButton(gridLayoutWidget);
            pushButton46->setObjectName(QString::fromUtf8("pushButton46"));
            pushButton46->setMinimumSize(QSize(80, 80));
            pushButton46->setMaximumSize(QSize(80, 80));
            pushButton46->setStyleSheet(QString::fromUtf8("background-color:rgb(241, 237, 233)"));
            pushButton46->setCheckable(false);

            gridLayout->addWidget(pushButton46, 4, 6, 1, 1);

            pushButton77 = new QPushButton(gridLayoutWidget);
            pushButton77->setObjectName(QString::fromUtf8("pushButton77"));
            pushButton77->setMinimumSize(QSize(80, 80));
            pushButton77->setMaximumSize(QSize(80, 80));
            pushButton77->setStyleSheet(QString::fromUtf8("background-color:rgb(241, 237, 233)"));
            pushButton77->setCheckable(false);

            gridLayout->addWidget(pushButton77, 7, 7, 1, 1);

            horizontalLayoutWidget = new QWidget(centralwidget);
            horizontalLayoutWidget->setObjectName(QString::fromUtf8("horizontalLayoutWidget"));
            horizontalLayoutWidget->setGeometry(QRect(20, 110, 172, 256));
            horizontalLayout_3 = new QHBoxLayout(horizontalLayoutWidget);
            horizontalLayout_3->setObjectName(QString::fromUtf8("horizontalLayout_3"));
            horizontalLayout_3->setContentsMargins(0, 0, 0, 0);
            verticalLayout_3 = new QVBoxLayout();
            verticalLayout_3->setObjectName(QString::fromUtf8("verticalLayout_3"));
            pieceChoice1 = new QPushButton(horizontalLayoutWidget);
            pieceChoice1->setObjectName(QString::fromUtf8("pieceChoice1"));
            pieceChoice1->setMinimumSize(QSize(80, 80));
            pieceChoice1->setMaximumSize(QSize(80, 80));
            pieceChoice1->setStyleSheet(QString::fromUtf8(""));
            pieceChoice1->setCheckable(false);

            verticalLayout_3->addWidget(pieceChoice1);

            pieceChoice2 = new QPushButton(horizontalLayoutWidget);
            pieceChoice2->setObjectName(QString::fromUtf8("pieceChoice2"));
            pieceChoice2->setMinimumSize(QSize(80, 80));
            pieceChoice2->setMaximumSize(QSize(80, 80));
            pieceChoice2->setStyleSheet(QString::fromUtf8(""));
            pieceChoice2->setCheckable(false);

            verticalLayout_3->addWidget(pieceChoice2);

            pieceChoice3 = new QPushButton(horizontalLayoutWidget);
            pieceChoice3->setObjectName(QString::fromUtf8("pieceChoice3"));
            pieceChoice3->setMinimumSize(QSize(80, 80));
            pieceChoice3->setMaximumSize(QSize(80, 80));
            pieceChoice3->setStyleSheet(QString::fromUtf8(""));
            pieceChoice3->setCheckable(false);

            verticalLayout_3->addWidget(pieceChoice3);


            horizontalLayout_3->addLayout(verticalLayout_3);

            verticalLayout = new QVBoxLayout();
            verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
            pieceChoice4 = new QPushButton(horizontalLayoutWidget);
            pieceChoice4->setObjectName(QString::fromUtf8("pieceChoice4"));
            pieceChoice4->setMinimumSize(QSize(80, 80));
            pieceChoice4->setMaximumSize(QSize(80, 80));
            pieceChoice4->setStyleSheet(QString::fromUtf8(""));
            pieceChoice4->setCheckable(false);

            verticalLayout->addWidget(pieceChoice4);

            pieceChoice5 = new QPushButton(horizontalLayoutWidget);
            pieceChoice5->setObjectName(QString::fromUtf8("pieceChoice5"));
            pieceChoice5->setMinimumSize(QSize(80, 80));
            pieceChoice5->setMaximumSize(QSize(80, 80));
            pieceChoice5->setStyleSheet(QString::fromUtf8(""));
            pieceChoice5->setCheckable(false);

            verticalLayout->addWidget(pieceChoice5);

            pieceChoice6 = new QPushButton(horizontalLayoutWidget);
            pieceChoice6->setObjectName(QString::fromUtf8("pieceChoice6"));
            pieceChoice6->setMinimumSize(QSize(80, 80));
            pieceChoice6->setMaximumSize(QSize(80, 80));
            pieceChoice6->setStyleSheet(QString::fromUtf8(""));
            pieceChoice6->setCheckable(false);

            verticalLayout->addWidget(pieceChoice6);


            horizontalLayout_3->addLayout(verticalLayout);

            ChessWindow->setCentralWidget(centralwidget);

            retranslateUi(ChessWindow);

            QMetaObject::connectSlotsByName(ChessWindow);
        } // setupUi

        void retranslateUi(QMainWindow* ChessWindow)
        {
            ChessWindow->setWindowTitle(QCoreApplication::translate("ChessWindow", "let's play chess!", nullptr));
            pushButton13->setText(QString());
            pushButton55->setText(QString());
            pushButton11->setText(QString());
            pushButton32->setText(QString());
            pushButton62->setText(QString());
            pushButton71->setText(QString());
            pushButton45->setText(QString());
            pushButton06->setText(QString());
            pushButton51->setText(QString());
            pushButton02->setText(QString());
            pushButton64->setText(QString());
            pushButton07->setText(QString());
            pushButton16->setText(QString());
            pushButton25->setText(QString());
            pushButton43->setText(QString());
            pushButton50->setText(QString());
            pushButton03->setText(QString());
            pushButton27->setText(QString());
            pushButton72->setText(QString());
            pushButton53->setText(QString());
            pushButton05->setText(QString());
            pushButton47->setText(QString());
            pushButton31->setText(QString());
            pushButton22->setText(QString());
            pushButton56->setText(QString());
            pushButton65->setText(QString());
            pushButton60->setText(QString());
            pushButton40->setText(QString());
            pushButton20->setText(QString());
            pushButton52->setText(QString());
            pushButton10->setText(QString());
            pushButton73->setText(QString());
            pushButton21->setText(QString());
            pushButton66->setText(QString());
            pushButton14->setText(QString());
            pushButton75->setText(QString());
            pushButton63->setText(QString());
            pushButton04->setText(QString());
            pushButton17->setText(QString());
            pushButton70->setText(QString());
            pushButton61->setText(QString());
            pushButton26->setText(QString());
            pushButton35->setText(QString());
            pushButton15->setText(QString());
            pushButton01->setText(QString());
            pushButton36->setText(QString());
            pushButton41->setText(QString());
            pushButton54->setText(QString());
            pushButton34->setText(QString());
            pushButton12->setText(QString());
            pushButton67->setText(QString());
            pushButton00->setText(QString());
            pushButton37->setText(QString());
            pushButton42->setText(QString());
            pushButton76->setText(QString());
            pushButton74->setText(QString());
            pushButton23->setText(QString());
            pushButton33->setText(QString());
            pushButton57->setText(QString());
            pushButton30->setText(QString());
            pushButton44->setText(QString());
            pushButton24->setText(QString());
            pushButton46->setText(QString());
            pushButton77->setText(QString());
            pieceChoice1->setText(QString());
            pieceChoice2->setText(QString());
            pieceChoice3->setText(QString());
            pieceChoice4->setText(QString());
            pieceChoice5->setText(QString());
            pieceChoice6->setText(QString());
        } // retranslateUi

    };

    namespace Ui {
        class ChessWindow : public Ui_ChessWindow {};
    } // namespace Ui
}
QT_END_NAMESPACE

#endif // VIEWXHXAII_H
